package RecursionAndBacktrackingLAB;

import java.util.Arrays;
import java.util.Scanner;

public class RecursiveArraySum {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int[] arr = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt)
                .toArray();

        int sumTwo = sumNumbers(arr, arr.length - 1);

        System.out.println(sumTwo);
    }


    private static int sumNumbers(int[] numbers, int i) {
        if (i < 0) {
            return 0;
        }

        return numbers[i] + sumNumbers(numbers, i - 1);
    }


}
